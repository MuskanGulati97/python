// Page Object Model

// Code duplicacy is reduced 
// Easy maintenance


